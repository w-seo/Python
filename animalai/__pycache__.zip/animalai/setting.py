
# Flickr Access Info
API_ACCESS_KEY = "b89a675382b6af5efde28baa6fadd30c"
API_SECRET_KEY = "59a6b01552fba337"

IMAGE_SAVE_DIR = "/home/phase1_animal/animalai/images/"
NPY_SAVE_DIR = "/home/phase1_animal/animalai/npy/"
MODEL_SAVE_DIR = "/home/phase1_animal/animalai/model/"
